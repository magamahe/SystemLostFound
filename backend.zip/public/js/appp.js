console.log("JS cargado correctamente");

// ======================================================
// 🌗 TOGGLE CLARO / OSCURO – ÚNICO, SIMPLE Y FUNCIONAL
// ======================================================
document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("theme-toggle");
  const root = document.documentElement;

  if (!toggleBtn) {
    console.error("No se encontró el botón #theme-toggle");
    return;
  }

  // Cargar tema guardado
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "light") {
    root.classList.remove("dark");
  } else {
    root.classList.add("dark");
    localStorage.setItem("theme", "dark");
  }

  // Cambiar tema al hacer click
  toggleBtn.addEventListener("click", () => {
    const isDark = root.classList.toggle("dark");
    localStorage.setItem("theme", isDark ? "dark" : "light");
  });
});

// ======================================================
// 🌐 CONFIGURACIÓN DE API
// ======================================================
const API_URL = "http://localhost:3000";

// ======================================================
// 🧠 ESTADO GLOBAL
// ======================================================
let currentUser = JSON.parse(localStorage.getItem("user")) || null;
let token = localStorage.getItem("token") || null;
let allItems = [];

// ======================================================
// 🚀 INICIO DE LA APP
// ======================================================
document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

// ======================================================
// 🛠️ FUNCIÓN PRINCIPAL
// ======================================================
async function initApp() {
  try {
    await loadItems();
    renderTab("general");
    updateNavbar();
    renderFloatingButton();
  } catch (error) {
    console.error("Error al iniciar la aplicación:", error);
  }
}

// ======================================================
// 🧭 NAVEGACIÓN POR TABS
// ======================================================
function renderTab(tabName) {
  const container = document.getElementById("cards-container");
  if (!container) return;

  container.innerHTML = "";

  const tabsNav = document.createElement("div");
  tabsNav.className =
    "col-span-full flex border-b border-gray-200 dark:border-gray-800 mb-8 gap-6";

  const tabs = [{ id: "general", label: "TABLÓN GENERAL", icon: "fa-globe" }];

  tabs.forEach((t) => {
    const btn = document.createElement("button");
    btn.className =
      "pb-4 px-4 font-bold transition-all " +
      (tabName === t.id
        ? "text-neonPurple border-b-4 border-neonPurple"
        : "text-gray-400 hover:text-white");

    btn.innerHTML = `<i class="fas ${t.icon} mr-2"></i>${t.label}`;
    btn.addEventListener("click", () => renderTab(t.id));
    tabsNav.appendChild(btn);
  });

  container.appendChild(tabsNav);

  const contentDiv = document.createElement("div");
  contentDiv.className = "col-span-full";
  container.appendChild(contentDiv);

  if (tabName === "general") renderGeneralTab(contentDiv);
}

// ======================================================
// 🧩 TAB GENERAL
// ======================================================
function renderGeneralTab(parent) {
  parent.innerHTML = "";

  if (allItems.length === 0) {
    parent.innerHTML = `
      <div class="text-center text-gray-500 dark:text-gray-400">
        <p>No hay publicaciones todavía.</p>
      </div>
    `;
    return;
  }

  const grid = document.createElement("div");
  grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6";

  allItems.forEach((item) => {
    const card = createCard(item);
    grid.appendChild(card);
  });

  parent.appendChild(grid);
}

// ======================================================
// 🧱 CREADOR DE TARJETAS
// ======================================================
function createCard(item) {
  const card = document.createElement("article");
  card.className =
    "bg-white dark:bg-darkCard rounded-2xl shadow-md p-4 flex flex-col";

  const fecha = item.createdAt
    ? new Date(item.createdAt).toLocaleDateString("es-AR")
    : "Sin fecha";

  card.innerHTML = `
    <p class="text-xs text-gray-400">${fecha}</p>
    <h3 class="font-bold text-lg mb-2">${item.title || "Sin título"}</h3>
    <p class="text-sm text-gray-500 flex-1">
      ${item.description || "Sin descripción"}
    </p>
  `;

  return card;
}

// ======================================================
// 📡 CARGAR ÍTEMS DESDE BACKEND
// ======================================================
async function loadItems() {
  try {
    const res = await fetch(`${API_URL}/items`);
    if (!res.ok) throw new Error("Error cargando ítems");

    allItems = await res.json();
  } catch (error) {
    console.error("No se pudieron cargar los ítems:", error);
    allItems = [];
  }
}

// ======================================================
// ➕ BOTÓN FLOTANTE
// ======================================================
function renderFloatingButton() {
  const oldBtn = document.getElementById("floating-add-btn");
  if (oldBtn) oldBtn.remove();

  if (!currentUser) return;

  const btn = document.createElement("button");
  btn.id = "floating-add-btn";
  btn.innerHTML = '<i class="fas fa-plus"></i>';
  btn.className =
    "fixed bottom-8 right-8 w-16 h-16 bg-neonPurple text-black rounded-full shadow-xl";

  document.body.appendChild(btn);
}

// ======================================================
// 🧭 NAVBAR
// ======================================================
function updateNavbar() {
  const userSection = document.getElementById("user-section");
  if (!userSection) return;

  userSection.innerHTML = "";

  if (currentUser) {
    const span = document.createElement("span");
    span.textContent = currentUser.username;
    span.className = "font-bold";

    const btnLogout = document.createElement("button");
    btnLogout.textContent = "Salir";
    btnLogout.className =
      "bg-red-500 text-white px-3 py-1 rounded ml-4";
    btnLogout.addEventListener("click", logout);

    userSection.appendChild(span);
    userSection.appendChild(btnLogout);
  } else {
    const btnLogin = document.createElement("button");
    btnLogin.textContent = "Ingresar";
    btnLogin.className =
      "bg-neonPurple text-black px-4 py-2 rounded";
    userSection.appendChild(btnLogin);
  }
}

// ======================================================
// 🚪 LOGOUT
// ======================================================
function logout() {
  currentUser = null;
  token = null;
  localStorage.clear();
  updateNavbar();
  renderTab("general");
  renderFloatingButton();
}
